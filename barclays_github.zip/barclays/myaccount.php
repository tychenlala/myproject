<?php include 'connect.php';
$userinfo = $_SESSION['user_profile_id'];
?>
<?php include 'user.page.php' ?>
<div class="container" style="width:95 %; background:#bbbbbb;margin-top:0px">
<div class="slideshow">
<div class="jumbotron" style="background:transparent; text-align:center">
  <h1 id="h1">Barclays Remittance Funds PLC.</h1>
  <h2>Affiliated with Barclays Bank PLC.</h2>
</div>
</div>
</div>
<div class="welcome">
  <?php
// $profile = mysqli_query($con, "SELECT * FROM barclays_login");
// $num_of_record = mysqli_num_rows($profile);
// if ($num_of_record >0) {
//   while ($record = mysqli_fetch_array($profile)) {
//   echo "<h1>"."Welcome! Mr. ". $record['first_name'].' '.$record['last_name']."<h1>";
//   }
// }
echo 'Welcome '.'Mr. '.  $_SESSION['user_profile_id'];
   ?>
  <h2 id="h2">Please you can perform your transactions via the link at the right top conner.</h2>
</div>
<?php include 'footer.php' ?>
