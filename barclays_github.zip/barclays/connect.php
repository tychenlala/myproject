<?php
session_start();
$con = mysqli_connect('localhost', 'root','', 'test');
if (!$con) {
  echo "Connection Error!";
}
?>
