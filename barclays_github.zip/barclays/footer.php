<div class="content container" style="width:95%">
  Barclays Remittance Funds PLC. Authorised by the Barclays Bank PLC. Barclays Bank UK PLC.
   Authorised by the Prudential Regulation Authority and regulated by the Financial Conduct
   Authority and the Prudential Regulation Authority (Financial Services Register number: 759676).
    Barclays Bank UK PLC adheres to The Standards of Lending Practice which is monitored and enforced
     by The Lending Standards Board. Further details can be found at
      <a href="https:///lendingstandardsboard.org.uk">www.lendingstandardsboard.org.uk</a>
</div>

<footer>
  <div class="container">
<div class="footer-page col-md-6">
  <address>
    &copy;Barclays Remittance Funds PLC.<br>
    Powered and Authorised by: Barclays PLC. 1 Churchill Place London, E14 5HP, UK. <br>
    All Right Reserved.
  </address>
</div>
<div class="footer-logo col-md-6">
  <img src="images/fscs.large.medium_quality.jpg" alt="">
  <img src="images/KiteMark_Footer_ROLB.large.medium_quality.png" alt="">
  <img src="images/Cyber_Footer_ROLB.large.medium_quality.jpg" alt="">
</div>
</div>
</footer>

  <script src="barclays-js/jquery.1.11.js" charset="utf-8"></script>
  <script src="barclays-js/bootstrap.js" charset="utf-8"></script>
  <script src="barclays-js/jquery.backstretch.min.js" charset="utf-8"></script>
  <script>
  $(".slideshow").backstretch([
    "images/handing-money6-1280x640.jpg",
    "images/tim.php.jpeg",
    "images/money-pile.jpg",
  ],
    {
      fade: 750,
      duration: 4000
  });
  $(".login").backstretch([
    "images/handing-money6-1280x640.jpg",
    "images/tim.php.jpeg",
    "images/money-pile.jpg",
  ],
    {
      fade: 750,
      duration: 4000
  });

    </script>
</body>
</html>
