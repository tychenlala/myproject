
<?php include 'links.head.php'; ?>
<div class="container" style="width:95%; background:#bbbbbb;margin-top:0px">
<div class="slideshow">
<div class="jumbotron" style="background:transparent; text-align:center">
  <h1 id="h1">Barclays Remittance Funds PLC.</h1>
  <h2>Affiliated with Barclays Bank PLC.</h2>
</div>
</div>
</div>
<div class="slider">
  <div class="sub-slider container" style="width:90%">
    <div class="row">
      <div class="sub-slider-one col-md-6">
<div class="manage-money"style="text-align:center">
  <h1 id="h2">Take Control Of Your Remittance Funds</h1>
  <img src="images/barclaycard_homepage_16_9.small.medium_quality.jpg" alt="" style="width:500px;height:300px">
  <h4>You can Transfer your t Funds anytime anywhere.</h4>
  <h5>Wants to Transfer? Please <a href="#">Log in</a> </h5>
  <h6>Terms and Conditions Apply</h6>
</div>
      </div>
      <div class="sub-slider-two col-md-6"style="text-align:center">
        <h2 id="h2">Barclays Remittance Department gives room for Funds boosting</h2>
<img src="images/ON-CH606_dollar_M_20171013181249.jpg" alt="" style="width:650px;height300px">
      </div>
    </div>
  </div>
</div>
<?php include 'footer.php' ?>
