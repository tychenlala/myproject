<?php include 'links.head.php'; ?>
<div class="about">

  <div class="container" style="width:95%">
    <div class="row"><h1 style="text-align:center">Our Goals</h1><hr>
    <div class="col-md-3">

    </div>
    <div class="col-md-6">
<h4>Remittances are a significant portion of external financing. In 2004, remittances
were recorded to be the the second largest source of external financing, after Foreign
 Direct Investment. "Remittances(appear to be) the least volatile source of foreign exchange
 earnings for developing countries in the 1990s" (Ratha). While remittances have been continually
 increasing since the 1990s, FDI has fluctuated, especially during the last decade</h4>
 <h4>"According to World Bank in 2006, the magnitude of remittances in many developing countries
    has surpassed official development assitance (ODA), private equity flows, and foreign Direct
     investment (FDI), and their rate of growth has outpaced that of official and private capital flows". </h4>
     <h4>
Remittances encompass a large part of their Gross Domestic Product (GDP). "Remittances to low-income
countries were larger as a share of GDP and imports than were those to middle income counries" (Ratha).
 In comparing larger countries with smaller ones, it appears that remittances in terms of the U.S. dollar
 flow out to larger countries. However, in terms of GDP, remittances flow out to smaller countries.</h4>
 <hr>
 <h2 style="text-align:center">Our Targets</h2>
 <ol>
   <li>Targeted to meet specific needs</li>
   <li>Finance the purchase of basic consumption goods, housing, and children's education and health care</li>
   <li>Provide capital for small businesses and entrepreneurial activities</li>
   <li>Pay for imports and external debt service</li>
   <li>Used by banks to raise overseas financing using future remittances as collateral</li>
   <li>Tend to be more stable than capital flows</li>
   <li>Tend to be counter-cyclical</li>
 </ol>
    </div>
    <div class="col-md-3" style="margin-top:100px">
<img src="images/extortion.jpg" class="img-rounded" style="width:300px;height:300px;">
<h5 style="color:#3771b0">You can have your money anytime anywhere</h5>
<p></p>
<img src="images/travelling_abroad_promo_16_9.small.medium_quality.jpg" class="img-rounded" style="width:300px;height:300px;">
<h5 style="color:#3771b0">Feel free to leave anywhere</h5>
    </div>
  </div>
  </div>
</div>










<?php include 'footer.php'; ?>
