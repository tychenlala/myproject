<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Barclays Remitance Department</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/css/bootflat.min.css">
    <link rel="stylesheet" href="css/barclays.css">
    <link rel="stylesheet" href="css/themify-icons/themify-icons.css">
<style media="screen">
@font-face {
      font-family: 'HelveticalNeue-Light';
      src: url('Helvetica/HelveticaNeueCyr-Light.otf');
            }
@font-face {
       font-family: 'HelveticalNeue-Ultralight';
       src: url('Helvetica/HelveticaNeueCyr-UltraLight.otf');
            }
@font-face {
       font-family: 'HelveticalNeue-Thin';
       src: url('Helvetica/HelveticaNeueCyr-Thin.otf');
            }
       #h1 {
         font-family: 'HelveticalNeue-Light';
           }
       #h2 {
         font-family: 'HelveticalNeue-Thin';
           }
           #h3 {
               font-family: 'HelveticalNeue-Ultralight';
             }
</style>
  </head>
  <body>
    <header>
      <div class="container">
    <div class="col-md-8">
    <a href="index.php">
     <img src="images/index.jpeg" style="width:150px;height:80px" alt=""> REMITTANCE FUNDS PLC.
   <!-- <small class="header-title-motto"><b></b></small> -->
 </a>
  </div>
<div class="col-md-4">
<div class="btn-group">
  <a class="btn btn-primary" href="barclays_myaccount.php" style="border-radius:20px"><span class="ti-user">My Account</span></a>
    <a class="btn" href="foreign.php"><span class="ti-mobile">Contact Us</span></a>
    <a class="btn" href="#"><span class="ti-location-pin">Find Branch</span></a>
  </div>
</div>
<div class="clearfix"></div>
</div>
</header>
<div class="navbar" style="margin-bottom:0px">
<nav class="navbar navbar-default" style="border-radius:0px; background:white;margin-bottom:0px">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
          <li><a class="navbar-brand" href="index.php">Home </a></li>
          <li><a href="about_barclays_remittance_funds.php" class="navbar-brand">About Us</a> </li>
  <li class="dropdown">
<a href="industries" class=" navbar-brand dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Intermediary <span class="caret"> </span></a>
  <ul class="dropdown-menu" role="menu">
    <li><a href="https://barclays.co.uk" class="navbar-brand">Barclays Bank PLC</a></li>
    <li class="divider"></li>
</ul>
  </li>
<li><a href="#" class="navbar-brand">News</a> </li>
      </ul>
<ul class="nav navbar-nav navbar-right">
<li><a class="btn btn-info" href="myaccount.transfer.php" style="border-radius:0px">Transfer</a> </li>
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" style="border-radius:0px">
  My profile
</button>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel" style="text-align:center"><h1 id="h1">Barclays Bank Account short details</h1></h4>
      </div>
      <div class="modal-body">
        <div class="row">

        <div class="name col-md-8">
          <?php
        $profile = mysqli_query($con, "SELECT * FROM barclays_login ORDER BY ID DESC");
        $num_of_record = mysqli_num_rows($profile);
        if ($num_of_record >0) {
          while ($record = mysqli_fetch_array($profile)) {
          echo "<h4>".'<b>'."NAME: ".'</b>'. $record['first_name'].' '.$record['last_name'];
          echo "<h4>".'<b>'."ADDRESS: ".'</b>'. $record['address'];
          echo "<h4>".'<b>'."MOTHER'S NAME: ".'</b>'. $record['mother_name'];
          echo "<h4>".'<b>'."NEXT OF KIN: ".'</b>'. $record['next_of_kin'];
          echo "<h4>".'<b>'."DATE OF BIRTH: ".'</b>'. $record['date_of_birth'];
          echo "<h4>".'<b>'."USERNAME: ".'</b>'. $record['username'];
          echo "<h4>".'<b>'."PASSWORD: ".'</b>'. $record['password'];

          }
        }
           ?>
<hr>
<h5><b>Account Balance: </b><h6 style="color:green"><b>$</b>6.8m</h6>
  <h5><b>Amount in words: </b><h6 style="color:green">Six million, eight hundred thousand US Dollar only<b/></h6>
      </div>
      <div class="col-md-4">
<img src="images/mohammed.jpg" class="img-rounded" style="width:150px;height:200px">
      </div>
    </div>
      </div>
    </div>
  </div>
</div>
<li class="navbar-brand">Ballance:<p style="color:#769a63"> $6.8m</li>
</ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav></div>
<div class="clearfix"></div>
