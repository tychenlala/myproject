<?php include 'user.page.php'; ?>
<div class="transfer">
  <div class="container" style="text-align:center">
    <div class="" style="color:red">

    <?php if (isset($_POST['acct_btn'])) {
      echo "<h3>"."Invalid F.E.C.N code!!!"."</h3>";
    } ?>
  </div>
    <h1 id="h1">Please fill the below form to transfer</h1>
    <div class="sub_transfer">
<form class="" method="post">
  <label for="">Please enter your Account Name</label>
  <input type="text" name="accountname"required class="form-control" placeholder="Account name" style="border-radius:0px">
  <label for="">Please enter your Account Number</label>
  <input type="num"required name="number" class="form-control" placeholder="Account number" style="border-radius:0px">
  <label for="">Please enter your email</label>
  <input type="email"required name="" value="" class="form-control" placeholder="email@example.com" style="border-radius:0px">
  <label for="">Please enter your Account Pin</label>
  <input type="pin" class="form-control" placeholder="Account Pin" required name="" value="" style="border-radius:0px">
  <label for="">please enter Your F.E.C.N code</label>
  <input type="text" name="fecn" required class="form-control" value="" style="border-radius:0px"placeholder="Foreign Exchange Certificate Number">
  <p></p>
  <button type="submit" class="btn btn-lg btn-info" name="acct_btn" style="border-radius:0px">Transfer</button>
  You don't have Foreign Exchange Certificate Number? <a href="foreign.php" style="color:red">click here</a>
</form>

  </div>
  </div>
</div>

<?php include 'footer.php'; ?>
