<?php include 'connect.php';?>
<?php include 'links.head.php'; ?>
<div class="login">
<h1 id="h2">Account Log In</h1>
<div class="container">
  <div style="color:red">
    <?php
    if (isset($_POST['btn-submit'])) {
      $username = $_POST['username'];
      $pass     = $_POST['password'];
      $profile  = mysqli_query($con, "SELECT * FROM barclays_login WHERE username = '$username' AND password = '$pass'");
      if (mysqli_num_rows($profile)>0) {
        $_SESSION['user_profile_id'] = $username;
        header('location:myaccount.php');
      }
      else {
        echo "<h3>"."Invalid Username or Password!"."</h3>";
      }
    }


     ?>
  </div>
<div class="loginshow" style="width:30%">
  <form class="" method="post">

  <label for="" id="h3">Enter Your Username and Password</label>
  <input type="text" name="username" class="form-control" placeholder="Username" required style="border-radius:20px"><br>
  <input type="password" class="form-control" name="password" placeholder="Password" required style="border-radius:20px"><br>
  <button type="submit" name="btn-submit" class="form-control btn btn-primary" style="border-radius:20px">Submit</button>
</form>

</div>
</div>
</div>




<?php include 'footer.php'; ?>
