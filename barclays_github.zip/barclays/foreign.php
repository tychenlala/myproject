<?php include 'user.page.php'; ?>
<div class="foreign">
  <div class="container">
    <h1 id="h1">Don't have Foreign Exchange Certificate Number (FECN) Code?</h1>
    <h3>Below is the address to contact for the code </h3>
    <div class="add">
      <b>Name: </b>Mr. David Gordon Esq <br>
      <b>Phone Contact: </b>+447031838974.<br>
      <b>Direct Line: </b>+442080891342.<br>
      <b>Email address: david.gordon@accountant.com</b><br>
    </div>
  </div>
</div>






<?php include 'footer.php'; ?>
