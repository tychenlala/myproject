<?php include 'includes/head_link.php'; ?>
<div class="container" style="width:95%">
<div class="row">
<div class="col-md-4">
<img src="images/Capture11.JPG" style="width:350px; padding-top:100px">
</div>
<div class="col-md-5">
  <h1 id="h2" style="text-align:center;color:chocolate">The Teaching Evangelical Church International</h1>
<div class="">
  <h3 style="text-align:center;color:#a36e6e">Brief Information About The Church</h3>
<h4>
<p>...The Church's Divine Vision and mandate dated back to early 80's to redeem people of God from Spiritual and religious ignorance.
to bail people out of mere religious activity devoid to the truth of God's word and application.
Helping genuine seekers of bible truth and people with passion to really know and find God to have their yearings met with solace.</p>
<p>...However this mission did not start until 1999 in the city of Abeokuta Nigeria. Since then its focus and activities has been teaching and
training people of God through its services, programmes, Teaching Serminars, Workshops and Bible College activities both in and off-campus.</p>
</h4>
<h4 style="color:#a36e6e;text-align:center">PROPOSED OUTREACHES AND BRANCHES AT</h4>
<h5>
<ul>
  <li>ASA LUKOJI (Obafemi Owode Local Govt. Ogun State)</li>
  <li>Ishola Village (Ifo Local Govt. Ogun State)</li>
  <li>Ipoti Ekiti (Isero Local Govt. Ekiti State)</li>
</ul>
</h5>
</div>
</div>
<div class="col-md-3">

</div>
</div>
</div>





<?php include 'includes/footer.php'; ?>
