<?php include 'includes/connect.php'?>
<?php include 'includes/head_link.php';?>
<div class="container">
  <div class="well" style="">
    <form method="post">
      <h3>Please enter your details</h3>
      <div style="color:red">
        <?php
          if (isset($_POST['login'])) {
            $username = $_POST['username'];
            $pass     = $_POST['password'];
            $profile  = mysqli_query($con, "SELECT * FROM choir_login WHERE username = '$username' AND password = '$pass'");
            if (mysqli_num_rows($profile)>0) {
              $_SESSION['user_profile_id'] = $username;
              header('location:teci_choirister_forum.php');
            }
            else {
              echo "Invalid Username or Password!";
            }
          }
           ?>
      </div>
      <input type="text" name="username"class="form-control" required placeholder="username" style="background:transparent;border-radius:15px; width:300px;margin-left:auto;margin-right:auto"><br>
      <input type="password" name="password" required class="form-control" placeholder="password" style="background:transparent;border-radius:15px;width:300px;margin-left:auto;margin-right:auto"><br>
      <button class="btn-lg btn-primary form-control" type="submit" name="login" style="border-radius:15px;width:300px;margin-left:auto;margin-right:auto">Log in</button>
    </form>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
