<?php include 'includes/head_link.php'; ?>
<div class="container" style="width:95%">
<div class="row">
<div class="col-md-3">
<img src="images/Capture11.JPG" style="width:350px; padding-top:100px">
</div>
<div class="col-md-6">
  <h1 id="h2" style="text-align:center;color:chocolate">The Teaching Evangelical Church International</h1>
<div class="">
  <h3 style="text-align:center;color:#a36e6e">The Church is commited to:</h3>
  <ul>
    <li><h4>Sound Teaching of the Word of God.</h4></li>
    <li><h4>Furthering the cause and course of the Gospel; via the Great Commission-Go ye and teach all nations. Mat.28:19.</h4> </li>
    <li><h4>Uncompromising, Real Practical Christial Living.</h4> </li>
    <li><h4>Advancing the Quality and Potentials of the Whole Man-Body, Soul and Spirit.</h4> </li>
    <li><h4>Child Development, Rehabilitation and Family Welfare.</h4> </li>
    <li><h4>Qualitative Religious, Spiritual and Liberal Education.</h4> </li>
    <li><h4>Seminars, Evangelism, Ministry, Mission Outreach and Workshops.</h4> </li>
    <li><h4>Church Planting, Growth and Development.</h4> </li>
  </ul>
</div>
</div>
<div class="col-md-3">

</div>
</div>
</div>










<?php include 'includes/footer.php'; ?>
