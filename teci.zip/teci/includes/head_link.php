<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>The Teaching Evangelical Church Int'l</title>
    <link rel="stylesheet" href="css/teci.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="themify-icons/themify-icons.css">
  </head>
  <body>
    <div class="page_header">
      <div class="container">
      <div class="church_logo col-md-1" style="padding-left:0px">
        <img src="images/Capture1.JPG" class="img-rounded" style="width:100px;height:100px">
      </div>
<div class="name col-md-7" style="padding-left:10px;padding-top:30px">

        <h4 style="color:blue" id="h2">The Teaching Evangelical Church International.<br>
          <small style="color:#054aff">Opposite Olubara Palace, beside Precious Pharmarcy <br>
            Omida, Ibara Abeokuta, Ogun State Nigeria.</small>
        </h4>
      </div>
      <div class="social_media col-md-4">
        <a class="navbar-brand" href="#"><span class="ti-facebook">Facebook</span> </a>
        <a class="navbar-brand" href="#"><span class="ti-twitter-alt">Twitter</span></a>
        <a class="navbar-brand" href="#"><span class="ti-instagram">Instagram</span> </a>
      </div>
    </div>
  </div>
    <div class="clear"></div>
<div class="navbar" style="margin-bottom:0px">
<nav class="navbar navbar-default" style="border-radius:0px;background:#1232; margin-bottom:0px;">
  <div class="container-fluid" style="width:50%">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a class="navbar-brand" href="index.php">Home</a></li>
        <li><a class="navbar-brand" href="our_mission_and_vision.php">Mission & Vision</a></li>
          <li><a class="navbar-brand" href="about_us.php">About Us</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</div>
<div class="clear">

</div>
