<div>
  <h2 id="h2" style="text-align:center;color:red">Departmental User's Link</h2>
<div style="background:#1232">

<div class="row">
  <div class="container" style="width:90%;">
    <div class="col-md-4">
 </div>
  <div class="conclussion col-md-8" style="">
    <div class="row">

    <ul class="c1 col-md-3">
    <a href="teci_choirister_login.php">Choir Department</a><br>
    <a href="#">Usher Department</a><br>
    <a href="#">Sanctuary Keeper</a><br>
    <a href="#">Workers Department</a><br>
    </ul>
    <ul class="c2 col-md-3">
     <a href="#">Counseling Department</a><br>
    <a href="#">Engineering Department</a><br>
    <a href="#">Children & Youths Dep</a><br>
    <a href="#">Deaconry & Elders Dep</a><br>
  </ul>
  </div>
</div>

<div class="footer col-md-4">

</div>
</div>
</div>
<div class="address">
    &copy;2018. All Right Reserved.
  <i>Created by: Godwin A.E <span class="ti-mobile">+2347055045807</span></i></p>
</div>
<script src="js/jquery.1.11.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.backstretch.min.js" charset="utf-8"></script>
<script>
$(".slideshow").backstretch([
  "images/teci3.jpg",
  "images/teci.jpg",
  "images/teci2.jpg",
  ], {
  fade: 750,
  duration: 4000,
});
// $.backstretch([
//   "images/Capture2.JPG",
// ], {
//   fade: 750,
// });
</script>
  </body>
</html>
