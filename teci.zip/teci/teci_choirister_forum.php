<?php include 'includes/connect.php';
$userinfo = $_SESSION['user_profile_id'];
if (!$userinfo) {
  unset($_SESSION['user_profile_id']);
  header('location:teci_choirister_login.php');
}
 ?>
<?php include 'includes/head_link.php'; ?>
<div class="forum" style="width:100%;background:skyblue">
<div class="row" style="width:95%;margin:auto">
<h1 style="text-align:center;color:red">The Teaching Evangelical Ministry Choiristers' forum</h1>
<div class="col-md-3">
Lorem ipsum dolor sit amet, consectetur
adipisicing elit, sed do eiusmod tempor
incididunt ut labore et dolore magna aliqua.

</div>
<div class="col-md-6" style="background:#fff;border-radius:10px;margin-bottom:5px">
  <h3><b style="color:red">NOTE: </b>Only the Choiristers of the above named Ministry are allowed here. <i><small>THANKS.</small></i> </h3>
  <hr>
  <?php
  $query2 = mysqli_query($con, "SELECT * FROM choir_comments");
  $num_of_records = mysqli_num_rows($query2);
  if ($num_of_records > 0) {
  while($record = mysqli_fetch_array($query2)){
    print_r('<small> <i>'. $record['date'].'-- '.$record['name'].': '.'</i></small> ' .$record['comments']);
    echo "<hr>";
    }
  }
  if (isset($_POST['post'])) {
    $comments = $_POST['comment'];
    $query1 = mysqli_query($con, "INSERT INTO choir_comments(name, comments) VALUES('$userinfo', '$comments')");
    echo '<small><i>1 sec ago-- '. $userinfo.': </i></small> '. $comments;
    }
   ?>
<form class="form-inline form-fixed-bottom" method="post" >
  <textarea type="text" name="comment" value="" placeholder="Write your message here" style="width:85%;height:50px;border-radius:0px"></textarea>
  <!-- <input type="text" name="name" value="" placeholder="Enter your name"> -->
  <button class="btn-lg btn-info" type="submit" name="post" style="border-radius:0px">Post</button>
</form>
 </div>
<div class="co.-md-3">
<?php
echo 'Welcome! '. $userinfo;
 ?>
</div>
</div>
</div>


<?php include 'includes/footer.php' ?>
