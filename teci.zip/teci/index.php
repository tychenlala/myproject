<?php include 'includes/head_link.php'; ?>
<div class="header" style="background-color:#1232;margin-top: 0px;width: 100%;height: 400px; padding-top: 10px;height:400px">
<div class="slideshow">
    <div class="jumbotron col-md-10" style="height:390px; margin-left:105px; padding-top:10px; background:transparent;text-align:center">
      <h1 id="h2" style="color:#fff">The Teaching Evangelical Church International</h1>
    </div>
    </div>
</div>
<div class="programme">
<div class="container"><h1 style="text-align:center;padding-bottom:30px"><u>NEXT PROGRAMME.</u></h1>
  <div class="row">
    <div class="col-md-7">

<h2 id="h1" style="color:#e34234">Anniversary!   Anniversary!!   Anniversary!!!</h2>
<h3>The Teaching Evangelical Church International is having her CHILDREN ANNIVERSARY AND 2nd QUARTER REVIVAL PROGRAMME. Schedule as follows: </h3>
<h4> <i>REVIVAL THEME:</i> <b>AS ARROW IN THE HAND OF A MIGHTY MAN [Bi Ofa lowo Alagbara]</b>
<h4> <i>ANNIVERSARY THEME:</i> <b>  </b>
<p> <i>DATE: </i>FRI 22nd - SUN 24th JUNE 2018</p>
<p>VENUE: Church Auditorium, Opposite Olu-ibara palace, beside Precious Pharmacy Omida-Ibara, Abeokuta </p>
</h4>
<i style="color:red;padding-left:500px">Jesus is Lord!!!
</i>

</div>
<div class="col-md-5">

<img src="../images/IMG-20171004-WA0001.jpg" class="img-rounded" style="width:550px; height:400px">
</div>
</div>
</div>
</div>


<div class="row">
  <div class="col-md-6">
    <h2 id="h7" style="text-align:center; color: skyblue">Upcoming Programmes:</h2>
    <ol type="1">
      <li>CHILDREN ANNIVERSARY AND 2ND QUARTER REVIVAL.
<p>Date: fri 22nd - sun 24 june 2018</p>
      </li>
  <li>YOUTHS CONVENTION AND CHOIR ANNIVERSARY.
    <p>Date: thurs 26th - sun 29th 2018</p>
</li>
<li>WOMEN CONFERENCE.
<p>Date: fri 10th and sat 11th August 2018</p>
</li>
<li>CHURCH CONVENTION THANKSGIVING PROGRAMME.
  <p>Date: August 2018</p>
</li>
<li>3RD ANNUAL CHURCH RETREAT.
  <p>Date: fri 23rd - sun 25th Nov. 2018</p>
</li>
<li>END OF THE YEAR AND CHRISTMAS ACTIVITIES.
  <p>Date: December</p>
</li>

    </ol>
  </div>
  <div class="col-md-6">
  <h2 id="h4" style="text-align:center;color:chocolate">Must Know Facts:</h2>
  <ol type="i">
    <li>The fear of God is the Beginning of Wisdom. Therefore fear the Lord thy God.</li>
    <li>If God is by your side, who can be against you? Therefore Fear no Evil for thy Lord is by thy side.</li>
  <li>JESUS said "I am the Way, the Truth and the Life." Why are you seeking the pleasure in the World, When
     there's treasure in the Lord. Therefore seek the Kingdom of God (TREASURE) first and every other shall be added to.</li>
  </ol>
  </div>
  </div>
  <div class="container" style="width:95%;">
  <div class="row">
    <h4 style="text-align:center;color:red">HIGHLIGHTS OF OUR EVENTS AND SERVICES</h4>
  <div class="col-md-4">
  <h5 style="text-align:center">WEEKLY EVENTS</h5>
<ul>
  <li><b><i>TEUSDAY: </i></b>Night Vigil.</li>
  <li><b><i>WEDNESDAY: </i></b>Intercessors Fellowship Prayer, Teens and Youths Programme(Twice Monthly) [5.00pm - 7.00pm].</li>
  <li><b><i>THURSDAY: </i></b><ol><li>Bible School Programme [9.00am - 2.00pm].</li>
  <li>Sunday School Teachers' Class [5.00pm - 7.30pm].</li></ol></li>
  <li><b><i>SATURDAY: </i></b>Choir and Studends Activities [3.00pm - 6.00pm].</li>
  <li><b><i>SUNDAY: </i></b><ol><li>Workers Prayer [8.30am - 9.00am].</li> <li>Sunday School [9.00am - 10.00am].</li>
     <li>Worship Service [10.00am - 12.30pm(Varies)].</li></ol></li>
</ul>
  </div>
  <div class="col-md-4">
      <h5 style="text-align:center">MONTHLY EVENTS</h5>
  <ul>
    <li><b><i>1st SUNDAY: </i></b>Thanksgiving and Worship Service.</li>
    <li><b><i>2nd SUNDAY: </i></b>Family Front.</li>
    <li><b><i>3rd SUNDAY: </i></b>Evangelism and Soul Winning.</li>
    <li><b><i>EVERY 20th: </i></b>Women On Their Neels Programme.</li>
    <li><b><i>1st FRIDAY: </i></b>Children and Youths Vigil of Teaching, Expositions and Prayers</li>
    <li><b><i>LAST FRIDAY: </i></b>General Vigil</li>
  </ul>
  </div>
  <div class="col-md-4">
    <h5 style="text-align:center">ANNUAL PROGRAMME</h5>
  <ul>
    <li><b><i>1st - 7th JANUARY: </i></b>7 DAYS VIGIL WITH EPIPHANY DAY CELEBRATION EVERY JANUARY 6th</li>
    <li><b><i>FEBRUARY: </i></b>Family and Couples' Day</li>
    <li><b><i>MARCH: </i></b>Ajodun Awon Agba ati Arugbo</li>
    <li><b><i>APRIL: </i></b>Easter Children Retreat</li>
    <li><b><i>JUNE: </i></b>Children Anniversary</li>
    <li><b><i>JULY: </i></b>Thanksgiving and Worship Service</li>
    <li><b><i>AUGUST: </i></b>Women Conference</li>
    <li><b><i>1st WEEK OF OCTOBER: </i></b>Church Anniversary and Convention</li>
    <li><b><i>NOVEMBER: </i></b>Church General Retreat</li>
    <li><b><i>DECEMBER: </i></b>End of Year Activity</li>
  </ul>
  </div>
  </div>
  </div>
<?php include 'includes/footer.php'; ?>
